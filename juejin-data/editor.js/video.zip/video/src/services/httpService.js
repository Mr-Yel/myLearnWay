import axios from 'axios'
import { storage } from "../utils/storage.js"
import { url } from "../config/index.js";

export class HttpService {
    static addQuery(url, str) {
        return url += /\?/g.test(url) ? `&${str}` : `?${str}`;
    }

    static async exeTicketLogin(ticket) {
        return this.post(url.baseUrl + '/api/v1/login/exe', {
            ticket
        })
    }

    static async validToken() {
        return HttpService.post(url.baseUrl + '/api/v1/public/valid', {})
    }

    static async getToken() {
        this.token = await storage.getData("token");
        return this.token
    }

    static async upload(url, data) {
        await HttpService.getToken();
        const result = await axios({
            method: 'post',
            url,
            headers: {
                'Content-Type': 'application/json',
                'token': this.token
            },
            data,
            validateStatus: function(status) {

                if (status === 401) {
                    HttpService.invalid();
                }
                return status >= 200 && status < 300; // default
            },
            transformRequest: [function(data, headers) {
                // Do whatever you want to transform the data
                headers['Content-Type'] = 'multipart/form-data'
                return data;
            }],
            transformResponse: [function(data) {
                const result = JSON.parse(data);
                if (!result.success && result.code === 500) {
                    // message.error(result.msg);
                    console.log("error");
                }
                return result;
            }],
        });

        if (result && result.status) {
            return result.data
        } else {
            alert('请求出错')
        }
    }

    static async post(url, data) {
        await HttpService.getToken();
        const result = await axios({
            method: 'post',
            url,
            headers: {
                'Content-Type': 'application/json',
                "token": this.token
            },
            data,
            validateStatus: function(status) {
                if (status === 401) {
                    HttpService.invalid();
                }
                return status >= 200 && status < 300; // default
            },
            transformResponse: [function(data) {
                const result = JSON.parse(data);
                if (!result.success && result.code === 500) {
                    console.log("post + error");
                }
                return result;
            }],
        });

        if (result && result.status) {
            return result.data
        } else {
            alert('请求出错')
        }

    }

    static async put(url, data) {
        await HttpService.getToken();
        const result = await axios({
            method: 'put',
            url,
            headers: {
                'Content-Type': 'application/json',
                'token': this.token
            },
            data,
            validateStatus: function(status) {
                if (status === 401) {
                    HttpService.invalid();
                }
                return status >= 200 && status < 300; // default
            },
            transformResponse: [function(data) {
                const result = JSON.parse(data);
                if (!result.success && result.code === 500) {
                    console.log("put + error");
                }
                return result;
            }],
        });

        if (result && result.status) {
            return result.data
        } else {
            alert('请求出错')
        }
    }

    static async get(url, data) {
        await HttpService.getToken();
        if (data) {
            let query = [];
            for (let key in data) {
                query.push(`${key}=${data[key]}`)
            }
            url = HttpService.addQuery(url, query.join('&'))
        }
        const result = await axios({
            method: 'get',
            url,
            headers: {
                'token': this.token
            },
            data,
            validateStatus: function(status) {
                if (status === 401) {
                    HttpService.invalid();
                }
                return status >= 200 && status < 300; // default
            },
            transformResponse: [function(data) {
                const result = JSON.parse(data);
                if (!result.success && result.code === 500) {
                    console.log("get + error");
                }
                return result;
            }],
        });

        if (result && result.status) {
            return result.data
        } else {
            alert('请求出错')
        }

    }

    static async delete(url, data) {
        await HttpService.getToken();

        if (data) {
            let query = [];
            for (let key in data) {
                query.push(`${key}=${data[key]}`)
            }
            url = HttpService.addQuery(url, query.join('&'))
        }
        // Send a GET request
        const result = await axios({
            method: 'delete',
            url,
            headers: {
                'token': this.token
            },
            data,
            validateStatus: function(status) {
                if (status === 401) {
                    HttpService.invalid();
                }
                return status >= 200 && status < 300; // default
            },
            transformResponse: [function(data) {
                const result = JSON.parse(data);
                if (!result.success && result.code === 500) {
                    console.log("delete + error");
                }
                return result;
            }],
        });

        if (result && result.status) {
            return result.data
        } else {
            alert('请求出错')
        }

    }

    static async invalid() {
        const iframe = document.querySelector('#iframe-container')
        iframe.contentWindow.postMessage({
            type: 'logout',
            value:''
        }, '*');
        // await localForage.clear();
        const event = new Event('token:invalid');
        if (window.dispatchEvent) {
            window.dispatchEvent(event);
        } else {
            window.fireEvent(event);
        }
    }
}