import { url } from '../config';
import { HttpService } from './httpService';
export default class ApiService {
    /**
     * 使用exe的token登录
     *
     * @static
     * @param {*} ticket
     * @returns
     * @memberof ApiService
     */
    static exeTicketLogin(ticket) {
        return HttpService.post(url.baseUrl + '/api/v1/login/exe', {
            ticket
        })
    }

    /**
     * 通过exe ticket获取exe用户信息
     *
     * @static
     * @param {*} ticket
     * @returns
     * @memberof ApiService
     */
    static getExeUser(ticket) {
        return HttpService.get(url.exeLoginUrl + '/api/Ticket/V2', {
            id: ticket
        })
    }

    static getArticleList(data) {
        return HttpService.get(url.baseUrl + '/api/v1/blocks', data)
    }

    static validToken() {
        return HttpService.post(url.baseUrl + '/api/v1/public/valid', {})
    }

    static getFileList(data) {
        return HttpService.get(url.baseUrl + '/api/v1/files', data)
    }
}