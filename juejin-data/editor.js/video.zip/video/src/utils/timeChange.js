
//时间转化 暂时不考虑大于一小时的情况
export function timeChange(time){
    let times = parseInt(time)
    if(times < 60){
        return "00:" + (times>=10?times:"0"+times)
    }
    if(times < 3600){
        let second = times%60
        let branch = parseInt(times/60)
        return (branch>=10?branch:"0"+branch) + ":" + (second>=10?second:"0"+second)
    }
    return 1
}
