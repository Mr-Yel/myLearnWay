export function dragSplit(leftElement, rightElement, midElement) {
    const leftEle = document.querySelector(leftElement);
    const rightEle = document.querySelector(rightElement);
    const midEle = document.querySelector(midElement);

    const splitMinLeft = 209; // 分隔条左边部分最小宽度
    const splitMaxLeft = 408; // 分隔条左边部分最大宽度
    midEle.onmousedown = handleLineMouseDown;

    function handleLineMouseDown(e) {
        document.onmousemove = function(e) {
            // console.log(e.clientX);
            let X = e.clientX / window.innerWidth
            leftEle.style.width = X * 100 + "%"
                // console.log(X,window.innerWidth,(window.innerWidth - X - 1));
            rightEle.style.width = (1 - X - 0.01) * 100 + "%"
            return false;
        };

        // 鼠标放开的时候取消操作
        document.onmouseup = function() {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    }
}