let debounceTimer = {}
    // TODO 多处地方同时调用debounce时，如果第一个传的是ahead = true，另外一个传的是ahead = false, 有可能造成两个的method方法都不会被嗲用
export const debounce = ({ method, delay = 300, ahead = false, type = 'common' }) => {
    // console.log('已阻止频繁触发..........', ahead)
    if (ahead && !debounceTimer[type]) {
        method()
    }
    clearTimeout(debounceTimer[type])
    debounceTimer[type] = setTimeout(() => {
        if (!ahead) {
            method()
        }
        clearTimeout(debounceTimer[type])
        debounceTimer[type] = undefined
    }, delay);
}