export const url = {
    // baseUrl: 'http://127.0.0.1:7002',
    // exeQRLogin: 'https://t-sso.exexm.com/qrlogin.ashx'
    // exeLoginUrl: 'https://t-sso.exexm.com',
    baseUrl: 'https://eftapi.exexm.com',
    exeQRLogin: 'https://sso.exexm.com/qrlogin.ashx',
    exeLoginUrl: 'https://sso.exexm.com',
}

//登录接口
export const loginQrCodeParams = {
    // getQrCodeUrl: "https://t-sso.exexm.com/qrlogin.ashx", // 获取APPid接口
    // qrCodeStateUrl: "https://t-sso.exexm.com/qrlogin.ashx", // 轮询接口
    getQrCodeUrl: 'https://sso.exexm.com/qrlogin.ashx', // 正式获取APPid接口
    qrCodeStateUrl: 'https://sso.exexm.com/qrlogin.ashx', // 正式轮询接口
}