//视频默认配置
export const videoOption = {
    id: "mse",
    volume: 0.3, //预设音量大小
    loop: true, //循环播放
    videoInit: true,
    autoplay: false, //自动播放
    playbackRate: [0.5, 0.75, 1, 1.5, 2], //播放倍速
    defaultPlaybackRate: 1, //默认倍速
    playbackRateUnit: 'x', //倍速后面的图标
    // lastPlayTime: 20, //视频起播时间（单位：秒）
    // lastPlayTimeHideDelay: 5, //提示文字展示时长（单位：秒）
    url: "https://sf1-cdn-tos.huoshanstatic.com/obj/media-fe/xgplayer_doc_video/mp4/xgplayer-demo-720p.mp4",
    height: (window.innerHeight * 0.94),
    width: window.innerWidth,
    poster: "",
    screenShot: {
        saveImg: true,
        type: 'image/png',
        format: '.png'
    },
    pip: true,
}