import Player from 'xgplayer';
import { HttpService } from "../../services/httpService.js";
import { screenShot } from "../editor/editor.js"
import { dataURLtoFile } from "../../utils/dataURLtoFile.js"
import { url } from "../../config/index.js";
import { videoOption } from "./config.js";
import { emitter } from "../../utils/mitt.js"
import { getThumbnails } from 'video-metadata-thumbnails';
import { storage } from '../../utils/storage.js';

export let playerInstance = null

/*
 * 截图方法
 * 改为直接调用screenShot()方法截图
 * 而不是发布截图事件，发布会有着一点点时间的延迟，导致时间与图片不符
 */
export function getScreenShot(callback) {
    playerInstance.once("screenShot", (screenShotImg) => {
        const file = dataURLtoFile(screenShotImg, "screenshot.png")
        const formData = new FormData();
        formData.append("file", file);
        HttpService.upload(url.baseUrl + "/api/v1/upload", formData).then((res) => {
            callback(res)
        });
    });
    playerInstance && playerInstance.screenShot()
}

function createPlayer(data) {
    let config = {}
    if (!data) {
        config = videoOption
    } else {
        config = {
            id: "mse",
            volume: 0.3, //预设音量大小
            loop: data.loop || true, //循环播放
            videoInit: true,
            autoplay: data.autoplay || false, //自动播放
            playbackRate: [0.5, 0.75, 1, 1.5, 2], //播放倍速
            defaultPlaybackRate: 1, //默认倍速
            playbackRateUnit: 'x', //倍速后面的图标
            // lastPlayTime: 20, //视频起播时间（单位：秒）
            // lastPlayTimeHideDelay: 5, //提示文字展示时长（单位：秒）
            url: data.url || "https://sf1-cdn-tos.huoshanstatic.com/obj/media-fe/xgplayer_doc_video/mp4/xgplayer-demo-720p.mp4",
            // height: (window.innerHeight * 0.92),
            // width: window.innerWidth,
            poster: data.poster || "",
            screenShot: {
                saveImg: data.saveImg || false,
                type: 'image/png',
                format: '.png'
            },
            pip: true,
        }
    }
    player(config)
}

//创建视频 
async function player(data) {
    playerInstance = new Player(data);

    playerInstance.once('ready', () => {
        setTimeout(function () {
            getVideoCover()
            //上传封面
        }, 1000);
    }) //保存封面

    //监听视频跳转事件
    emitter.on("timeJump", (data) => {
        playerInstance.currentTime = data
        // playerInstance.pause()
        playerInstance.play()
    })
}


/*
 * 截图点击方法
 */
function handleScreenshot() {
    getScreenShot((res) => {
        screenShot({
            file: { url: res.data.imgUrl, }
        })
    })
}

/*
 * 给按钮添加监听，调用截图方法
 */
function listenScreenShot() {
    let screenshot = document.querySelector(".screenshot");
    screenshot.addEventListener("click", handleScreenshot);
}

/*
 * 获取封面
 */
export async function getVideoCover() {
    if (playerInstance && playerInstance.video && playerInstance.video.currentSrc) {
        const thumbnails = await getThumbnails(playerInstance.video.currentSrc, {
            quality: 0.6,
            start: 1,
            end: 1
        });
        let files = new File([thumbnails[0].blob], 'cover.png', { type: 'image/jpeg' })
        const formData = new FormData();
        formData.append("file", files);
        HttpService.upload(url.baseUrl + "/api/v1/upload", formData).then(res => {
            if (res && res.data && res.data.imgUrl) {
                storage.setData("propNoteCover", res.data.imgUrl)
            }
        })
        // return HttpService.upload(url.baseUrl + "/api/v1/upload", formData);
    }
}


/*
 * 向外暴露方法获取当前视频的播放时间
 */
export function getScreenShotTime() {
    return playerInstance.currentTime
}

export const  video = async (videoOption) => {
    // return new Promise((resolve) => {
    createPlayer(videoOption)
    listenScreenShot()
    // })
}