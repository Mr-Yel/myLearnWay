import PostMate from "Postmate";
import { getScreenShot, getScreenShotTime } from "../video/video.js";
import { emitter } from "../../utils/mitt.js";
import { renderNoteList, renderPageNum } from '../notePage/initNotePage.js'
import { logout } from "../login/login.js"
import swal from 'sweetalert';

export function iframeConnect(name = 'my-iframe-name') {
    const handshake = new PostMate({
        container: document.getElementById('iframe-container'),
        url: './iframe.html',
        name,
        classListArray: ["myClass"]
    });


    const iframe = document.querySelector('#iframe-container')
    const vd = document.querySelector('video')
    handshake.then(child => {
        //发送页面video是否存在
        iframe.contentWindow.postMessage({
            type: 'isVideo',
            value: vd ? true:false,
        }, '*');
        child.on('logout', (data) => {
            console.log(data);
            logout()
        });
        child.on('screenshot', (data) => {
            getScreenShot((res) => {
                if (res && res.data && res.data.imgUrl) {
                    iframe.contentWindow.postMessage({
                        type: 'screenshot',
                        value: res.data.imgUrl
                    }, '*');
                    return
                }
                iframe.contentWindow.postMessage({
                    type: 'screenshot',
                    value: res
                }, '*');
            })
        });
        child.on('Flag', (data) => {
            iframe.contentWindow.postMessage({
                type: 'Flag',
                value: getScreenShotTime()
            }, '*');
        });
        child.on('timeJump', (data) => {
            emitter.emit("timeJump", data);
        });
        child.on('save', (data) => {
            renderNoteList()
            renderPageNum()
        });
        child.on('swal', (data) => {
            swal({
                title: data.title || '',
                text: data.text || '',
                icon: data.type || '',
                button: data.type || '',
              });
        });
        //发送页面video是否存在
        iframe.contentWindow.postMessage({
            type: 'isVideo',
            value: vd ? true : false,
        }, '*');
    });
}