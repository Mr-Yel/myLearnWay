export class Drag {
  constructor(data) {
    this.dragBox = null;
    this.data = data;
    this.buttonSet = {
      close: {
        icon: this.data.buttonSet ? data.buttonSet.icon : "",
      },
    };
    this.dragMinWidth = 250;
    this.dragMinHeight = 124;
    this._newDrag(this.data);
  }
  _newDrag(data) {
    try {
      this._creatElm(data); //根据配置创建窗口
      this._changeSize(data);
      this._dragElm(data);
    } catch (error) {
      console.log(error);
    }
  }
  _creatElm(data) {
    this.dragBox = document.createElement("div");
    this.dragBox.className = "dragBox";
    this.dragBox.style = `
    width: 100%;
    height: 100%;
    `

    const titleBox = document.createElement("div");
    titleBox.className = "title";
    const title = document.createElement("h2");
    const titleContent = document.createTextNode(
      data.title ? data.title : "拖动窗口"
    );
    const titleSelect = document.createElement("div");
    if (this.data.buttonSet) {
      for (let button in this.data.buttonSet) {
        if (button == 'close') {
          continue
        } else {
          let item = document.createElement("a");
          item.className = this.data.buttonSet[button].class ? this.data.buttonSet[button].class : '';
          item.addEventListener('click', this.data.buttonSet[button].callBack)
          item.onmousedown = function (event) {
            this.onfocus = function () { this.blur() };
            (event || window.event).cancelBubble = true
          };
          item.innerHTML = this.data.buttonSet[button].icon ? this.data.buttonSet[button].icon : '';
          titleSelect.appendChild(item)
        }
      }
    }
    if ((this.data.buttonSet.close).toString() != 'false') {
      const close = document.createElement("a");
      close.className = "close";
      close.addEventListener('click', this._closeDrag)
      close.onmousedown = function (event) {
        this.onfocus = function () { this.blur() };
        (event || window.event).cancelBubble = true
      };
      close.innerHTML = `<svg t="1642731525215" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2174" width="200" height="200"><path d="M511.333 127.333c51.868 0 102.15 10.144 149.451 30.15 45.719 19.337 86.792 47.034 122.078 82.321 35.287 35.286 62.983 76.359 82.321 122.078 20.006 47.3 30.15 97.583 30.15 149.451s-10.144 102.15-30.15 149.451c-19.337 45.719-47.034 86.792-82.321 122.078-35.286 35.287-76.359 62.983-122.078 82.321-47.3 20.006-97.583 30.15-149.451 30.15s-102.15-10.144-149.451-30.15c-45.719-19.337-86.792-47.034-122.078-82.321-35.287-35.286-62.983-76.359-82.321-122.078-20.006-47.3-30.15-97.583-30.15-149.451s10.144-102.15 30.15-149.451c19.337-45.719 47.034-86.792 82.321-122.078 35.286-35.287 76.359-62.983 122.078-82.321 47.301-20.006 97.583-30.15 149.451-30.15m0-64c-247.424 0-448 200.576-448 448s200.576 448 448 448 448-200.576 448-448-200.576-448-448-448z" fill="#515151" p-id="2175"></path><path d="M557.254 512l147.373-147.373c12.497-12.497 12.497-32.758 0-45.255-12.496-12.497-32.758-12.497-45.254 0L512 466.746 364.627 319.373c-12.497-12.497-32.758-12.497-45.255 0s-12.497 32.758 0 45.255L466.746 512 319.373 659.373c-12.497 12.496-12.497 32.758 0 45.254C325.621 710.876 333.811 714 342 714s16.379-3.124 22.627-9.373L512 557.254l147.373 147.373C665.621 710.876 673.811 714 682 714s16.379-3.124 22.627-9.373c12.497-12.496 12.497-32.758 0-45.254L557.254 512z" fill="#515151" p-id="2176"></path></svg>`
      titleSelect.appendChild(close)
    }
    title.appendChild(titleContent);
    titleBox.appendChild(title);
    titleBox.appendChild(titleSelect);

    const resizeL = document.createElement("div");
    resizeL.className = "resizeL";
    const resizeT = document.createElement("div");
    resizeT.className = "resizeT";
    const resizeR = document.createElement("div");
    resizeR.className = "resizeR";
    const resizeB = document.createElement("div");
    resizeB.className = "resizeB";
    const resizeLT = document.createElement("div");
    resizeLT.className = "resizeLT";
    const resizeTR = document.createElement("div");
    resizeTR.className = "resizeTR";
    const resizeBR = document.createElement("div");
    resizeBR.className = "resizeBR";
    const resizeLB = document.createElement("div");
    resizeLB.className = "resizeLB";

    const content = document.createElement("div");
    content.className = "content";
    if (this.data.content) {
      // const contentTest = document.createTextNode(this.data.content);
      // content.appendChild(contentTest);
      content.innerHTML = this.data.content;
    }

    this.dragBox.appendChild(titleBox);
    this.dragBox.appendChild(resizeL);
    this.dragBox.appendChild(resizeT);
    this.dragBox.appendChild(resizeR);
    this.dragBox.appendChild(resizeB);
    this.dragBox.appendChild(resizeLT);
    this.dragBox.appendChild(resizeTR);
    this.dragBox.appendChild(resizeBR);
    this.dragBox.appendChild(resizeLB);
    this.dragBox.appendChild(content);
    document
      .querySelector(data.id ? "#" + data.id : "." + data.class)
      .appendChild(this.dragBox);
  }
  /*
  * 关闭按钮的默认点击
  */
  _closeDrag() {
    let drag = document.querySelector("#drag")
    drag.style.display = "none"
  }
  /*
  * 绑定所以拖拽事件
  */
  _changeSize(data) {
    let oDrag = document.querySelector("#drag");
    let oLT = document.querySelector(".resizeLT");
    let oTR = document.querySelector(".resizeTR");
    let oBR = document.querySelector(".resizeBR");
    let oLB = document.querySelector(".resizeLB");
    let oL = document.querySelector(".resizeL");
    let oT = document.querySelector(".resizeT");
    let oR = document.querySelector(".resizeR");
    let oB = document.querySelector(".resizeB");
    //四角
    this.resize(oDrag, oLT, true, true, false, false);
    this.resize(oDrag, oTR, false, true, false, false);
    this.resize(oDrag, oBR, false, false, false, false);
    this.resize(oDrag, oLB, true, false, false, false);
    //四边
    this.resize(oDrag, oL, true, false, false, true);
    this.resize(oDrag, oT, false, true, true, false);
    this.resize(oDrag, oR, false, false, false, true);
    this.resize(oDrag, oB, false, false, true, false);
    oDrag.style.left =
      (document.documentElement.clientWidth - 200) / 2 + "px";
    oDrag.style.top =
      (document.documentElement.clientHeight - 400) / 2 + "px";
    //  oDrag.style.left =
    //     (document.documentElement.clientWidth - oDrag.offsetWidth) / 2 + "px";
    //   oDrag.style.top =
    //     (document.documentElement.clientHeight - oDrag.offsetHeight) / 2 + "px";
  }
  /*
   *获取id, class, tagName
   */
  get = {
    byId: function (id) {
      return typeof id === "string" ? document.getElementById(id) : id;
    },
    byClass: function (sClass, oParent) {
      var aClass = [];
      var reClass = new RegExp("(^| )" + sClass + "( |$)");
      var aElem = this.get.byTagName("*", oParent);
      for (var i = 0; i < aElem.length; i++)
        reClass.test(aElem[i].className) && aClass.push(aElem[i]);
      return aClass;
    },
    byTagName: function (elem, obj) {
      return (obj || document).getElementsByTagName(elem);
    },
  };
  /*-------------------------- +
拖拽函数
+-------------------------- */
  _dragElm(data) {
    let oDrag = document.querySelector("#drag")
    let handle = document.querySelector(".title")
    var disX = 0;
    var disY = 0;
    // var oMin = get.byClass("min", oDrag)[0];
    // var oMax = get.byClass("max", oDrag)[0];
    // var oRevert = get.byClass("revert", oDrag)[0];
    // var oClose = get.byClass("close", oDrag)[0];
    handle = handle || oDrag;
    handle.style.cursor = "move";
    handle.onmousedown = function (event) {
      var event = event || window.event;
      disX = event.clientX - oDrag.offsetLeft;
      disY = event.clientY - oDrag.offsetTop;
      document.onmousemove = function (event) {
        var event = event || window.event;
        var iL = event.clientX - disX;
        var iT = event.clientY - disY;
        var maxL = document.documentElement.clientWidth - oDrag.offsetWidth;
        var maxT = document.documentElement.clientHeight - oDrag.offsetHeight;
        iL <= 0 && (iL = 0);
        iT <= 0 && (iT = 0);
        iL >= maxL && (iL = maxL);
        iT >= maxT && (iT = maxT);
        oDrag.style.left = iL + "px";
        oDrag.style.top = iT + "px";
        return false;
      };
      document.onmouseup = function () {
        document.onmousemove = null;
        document.onmouseup = null;
        this.releaseCapture && this.releaseCapture();
      };
      this.setCapture && this.setCapture();
      return false;
    };
  }
  /*-------------------------- +
改变大小函数
+-------------------------- */
  resize(oParent, handle, isLeft, isTop, lockX, lockY) {
    let dragMinWidth = 300
    let dragMinHeight = 300

    handle.onmousedown = function (event) {

      var event = event || window.event;
      var disX = event.clientX - handle.offsetLeft;
      var disY = event.clientY - handle.offsetTop;
      var iParentTop = oParent.offsetTop;
      var iParentLeft = oParent.offsetLeft;
      var iParentWidth = oParent.offsetWidth;
      var iParentHeight = oParent.offsetHeight;

      const mask = document.createElement('div')
      mask.style.cssText = 'position: absolute;top: 0;left: 0;width: 100vw;height: 100vh;z-index: 9999;'
      mask.setAttribute('id', 'mousemoveMask')
      document.body.append(mask)
      // mask.addEventListener('mousemove', this.handleMousemove)

      mask.onmousemove = function (event) {
        var event = event || window.event;
        var iL = event.clientX - disX;
        var iT = event.clientY - disY;
        var maxW =
          document.documentElement.clientWidth - oParent.offsetLeft - 2;
        var maxH =
          document.documentElement.clientHeight - oParent.offsetTop - 2;
        var iW = isLeft ? iParentWidth - iL : handle.offsetWidth + iL;
        var iH = isTop ? iParentHeight - iT : handle.offsetHeight + iT;
        isLeft && (oParent.style.left = iParentLeft + iL + "px");
        isTop && (oParent.style.top = iParentTop + iT + "px");
        iW < dragMinWidth && (iW = dragMinWidth);
        iW > maxW && (iW = maxW);
        lockX || (oParent.style.width = iW + "px");
        iH < dragMinHeight && (iH = dragMinHeight);
        iH > maxH && (iH = maxH);
        lockY || (oParent.style.height = iH + "px");
        if (
          (isLeft && iW == dragMinWidth) ||
          (isTop && iH == dragMinHeight)
        )
          document.onmousemove = null;
        return false;
      };
      mask.onmouseup = function () {
        const mask = document.getElementById('mousemoveMask')
        mask && mask.removeEventListener('mousemove', this.handleMousemove)
        mask && mask.remove()
        mask.onmousemove = null;
        mask.onmouseup = null;
      };
      return false;
    };
  }
  getDefaultStyle(obj, attribute) { // 返回最终样式函数，兼容IE和DOM，设置参数：元素对象、样式特性
    return obj.currentStyle ? obj.currentStyle[attribute] : document.defaultView.getComputedStyle(obj, false)[attribute];
  }
}
