import { Drag } from "./drag.js";
import { drag_option } from "./config.js";

function createDrag(data) {
    const drag = new Drag(drag_option);
}
// {
//   id: "drag",
//   title: "我是一个窗口",
//   content: `
//   ① 窗口可以拖动；<br>
//   ② 窗口可以通过八个方向改变大小；<br>
//   ④ 限制窗口最小宽度/高度。`,
// }


export const drag = () => {
    // return new Promise((resolve) => {
    createDrag()
        // })
}