import EditorJS from '@editorjs/editorjs';

import { HttpService } from "../../services/httpService.js";
import { storage } from "../../utils/storage.js"
import { getVideoCover } from "../video/video.js"
import { url } from "../../config/index.js";
import { EDITOR_OPTIONS } from "./config.js";



export const editor = new EditorJS(EDITOR_OPTIONS)

//tab 切换
function tab() {
    const tab = initTab()
    tab[0].className = 'active'
    tab.forEach(item => {
        item.addEventListener('click', async function (e) {
            for (let i = 0; i < tab.length; i++) {
                tab[i].className = ''
            }
            e.currentTarget.className = 'active'
            if (e.currentTarget.id == 'show-note') {
                toNote()
            } else if (e.currentTarget.id == 'show-note-list') {
                toNoteList()
                getNoteId()
            }
        })
    })
}

function initTab() {
    const aside = document.querySelector('.aside')
    const tab = aside.querySelectorAll('p')
    for (let i = 0; i < tab.length; i++) {
        tab[i].className = ''
    }
    return tab
}

function toNote() {
    const note = document.querySelector('.note')
    const noteList = document.querySelector('.note-list')
    note.style.display = 'block'
    noteList.style.display = 'none'
    const tab = initTab()
    tab[0].className = 'active'
}

function toNoteList() {
    const note = document.querySelector('.note')
    const noteList = document.querySelector('.note-list')
    note.style.display = 'none'
    noteList.style.display = 'block'
}

//初始化note   
async function initNote() {
    await initNoteList()
    await initPage()
    const pageList = document.querySelector('#page-container')
    const noteListUl = document.querySelector('#note-container')

    const ListTypeMap = {
        publish(index) {
            console.log("发布");
        },
        async edit(index) {
            if (storage.getData("noteData") && storage.getData("noteData").blocks[0]) {
                const result = confirm('笔记区有内容未保存，是否继续？')
                if (result) {
                    await getNoteInfo(index)
                    editor.clear()
                    toNote()
                    storage.getData('noteData').blocks.forEach(item => {
                        editor.blocks.insert(item.type, item.data)
                    })
                    document.querySelector('.noteTitle-input').value = storage.getData('noteDataTitle') || ''
                }
            } else {
                await getNoteInfo(index)
                editor.clear()
                toNote()
                storage.getData('noteData').blocks.forEach(item => {
                    editor.blocks.insert(item.type, item.data)
                })
                document.querySelector('.noteTitle-input').value = storage.getData('noteDataTitle') || ''
            }
        },

        async delete(index) {
            const result = await HttpService.delete(url.baseUrl + '/api/v1/blocks/' + storage.getData('noteIdList')[index])
            if (result && result.data) {
                if (storage.getData('noteIdList')[index] == storage.getData('noteId')) {
                    storage.delData('noteId')
                }
                renderList()
                getNoteId()
                renderPage()
            }
        }
    }
    noteListUl.addEventListener('click', async (e) => {
        if (e.target && e.target.dataset) {
            const { type, index } = e.target.dataset
            if (ListTypeMap[type]) {
                ListTypeMap[type](index)
            }
        }
    })

    const pageTypeMap = {
        async next() {
            const pageBox = document.querySelector('#pageBox')
            const currentPage = pageBox.value
            const pageCount = await computePage()
            if (parseInt(currentPage) + 1 > pageCount) return
            const data = { page: parseInt(currentPage) + 1, pageSize: 10 }
            await renderList(data)
            await getNoteId(data)
            pageBox.value = parseInt(currentPage) + 1

        },
        async prev() {
            const pageBox = document.querySelector('#pageBox')
            const currentPage = pageBox.value
            if (parseInt(currentPage) - 1 <= 0) return
            const data = { page: parseInt(currentPage) - 1, pageSize: 10 }
            await renderList(data)
            await getNoteId(data)
            pageBox.value = parseInt(currentPage) - 1
        }
    }
    pageList.addEventListener('click', (e) => {
        if (e.target && e.target.dataset) {
            const { type } = e.target.dataset
            if (pageTypeMap[type]) {
                pageTypeMap[type]()
            }
        }
    })
}

//创建笔记列表
async function initNoteList() {
    const parent = document.querySelector('.note-list')
    const child = document.createElement('ul')
    child.className = "note-container"
    child.id = "note-container"
    parent.append(child)
    renderList()
}

//渲染笔记列表
async function renderList(data) {
    const noteListUl = document.querySelector('#note-container')
    const { noteList } = await getNoteList(data)
    let arr = ''
    noteList.forEach((item, index) => {
        arr = arr + `<li  class="note-item">
        <img src=${item.cover || "http://eftcdn.exexm.com/richText/assets/images/exe-img-placeholder-light.jpg?imageView2/5/w/200/h/200"} alt="封面">
        <div class="note-info">
            <h5>${item.title}</h5>
            <span>${item.createDate}</span>
        </div>
        <div class="note-operation">
            <button data-index=${index} data-type="publish" class="item-publish">发布</button>
            <button data-index=${index} data-type="edit" class="item-edit">编辑</button>
            <button data-index=${index} data-type="delete"  class="item-del">删除</button>
        </div>
    </li>`
    })
    noteListUl.innerHTML = arr
}

//创建分页
async function initPage() {
    const parent = document.querySelector('.note-list')
    const child = document.createElement('div')
    child.className = "page-container"
    child.id = "page-container"
    parent.append(child)
    renderPage()
}

//渲染分页
async function renderPage(index) {
    const page = document.querySelector('#page-container')
    const num = await computePage()
    page.innerHTML = ''
    page.innerHTML = `<span data-type="prev"><</span>
    <div class="page">
        <input type="number" 
        value="${index ? index : 1}"
        id="pageBox"
        > <em>/</em> ${num}
    </div>
    <span data-type="next">></span>`
}

//计算页数
export async function computePage() {
    const { noteNum } = await getNoteList()
    const page = Math.ceil(noteNum / 10)
    return page
}

//获取文章列表   
export async function getNoteList(num) {
    const noteData = await HttpService.get(url.baseUrl + '/api/v1/blocks', num ? num : 1)
    const noteList = await noteData.data.list
    const noteNum = await noteData.data.count
    return { noteList, noteNum }
}

//获取全部笔记id
async function getNoteId(data) {
    const { noteList } = await getNoteList(data)
    let noteIdList = {}
    noteList.forEach((item, index) => {
        noteIdList[index] = item._id
    });
    storage.setData('noteIdList', noteIdList)
}

//获取当前笔记信息
async function getNoteInfo(index) {
    const id = storage.getData('noteIdList')[index]
    const result = await HttpService.get(url.baseUrl + '/api/v1/blocks/' + id + '/edit')
    if (result && result.data) {
        storage.setData('noteId', id)
        storage.setData('noteData', JSON.parse(result.data.blocks))
        storage.setData('noteDataTitle', result.data.title)
    } else {
        console.log('获取文章信息失败');
    }
}

//监听保存事件
function listenSavaNote() {
    const save = document.querySelector('.save')
    save.addEventListener("click", saveNote)
}

// 保存数据
async function saveNote() {
    try {
        const outputData = await editor.save()
        if (!outputData.blocks[0]) {
            swal({
                icon: 'error',
                title: '没有数据，保存失败',
                text: '请输入正文内容'
            })
        }
        const cover = await getVideoCover() //获取封面
        const data = {
            cover: cover.data.imgUrl || "http://eftcdn.exexm.com/richText/assets/images/exe…mg-placeholder-light.jpg?imageView2/5/w/200/h/200",
            "blocks": JSON.stringify(outputData),
            title: document.querySelector('.noteTitle-input').value || 'title',
        }
        if (!storage.getData('noteId')) {
            const result = await HttpService.post(url.baseUrl + '/api/v1/blocks', data)
            if (result && result.data) {
                renderList()
                getNoteId()
                renderPage()
                editor.clear()
            }
        } else {
            const result = await HttpService.put(url.baseUrl + '/api/v1/blocks/' + storage.getData('noteId'), data)
            if (result && result.data) {
                storage.delData('noteId')
                editor.clear()
            }
        }
        // 清除标题
        document.querySelector('.noteTitle-input').value = ''
        swal({
            icon: 'success',
            title: '保存成功！'
        })
    } catch (error) {
        console.log('Saving failed: ', error)
    }
}

// 截屏
export function screenShot(data) {
    let focuseBlockIndex = editor.blocks.getCurrentBlockIndex() //获取当前焦点块，没有则返回-1
    let blocksCount = editor.blocks.getBlocksCount()  //获取当前总块数
    if (focuseBlockIndex >= 0) {
        let focuseBlockInnerHTML = editor.blocks.getBlockByIndex(focuseBlockIndex).holder  //获取当前焦点dom
        let text = focuseBlockInnerHTML.getElementsByClassName("ce-paragraph")[0]  //获取当前焦点text dom
        if (text && !text.innerHTML) {  //只有当前dom为text且innerHTML没有内容，替换
            editor.toolbar.close();
            editor.blocks.insert("screenShot", data, 1, focuseBlockIndex);
            return
        }
        //否则在下边插入
        editor.blocks.insert("screenShot", data, 1, focuseBlockIndex + 1);
        return
    }
    //没有焦点默认最下方插入
    editor.blocks.insert("screenShot", data, 1, blocksCount);
}

async function initTitle() {
    document.querySelector('.noteTitle-input').value = storage.getData('noteDataTitle') || ''
}


export const editorPage = () => {
    return new Promise(async (res) => {
        await initNote()
        initTitle()
        listenSavaNote()
        tab()
    })
}