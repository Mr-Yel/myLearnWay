import { editorTool } from './tools.js'
import { storage } from "../../utils/storage.js"
import { debounce } from '../../utils/debounce.js';

import { editor } from './editor.js';

//editor配置
export const EDITOR_OPTIONS = {
    holderId: "editorjs",
    placeholder: "开始你的创作！",
    data: storage.getData('noteData') || '',
    autofocus: true,
    tools: editorTool,
    logLevel: 'ERROR',
    onChange: handleChange
}
function handleChange() {
    debounce({
        method: () => {
            editor.save().then((outputData) => {
                console.log(outputData);
                storage.setData('noteData', outputData)
                storage.setData('noteDataTitle', document.querySelector('.noteTitle-input').value)
            }).catch((error) => {
                console.log('Saving failed: ', error)
            });
        },
        delay: 500,
    });
}