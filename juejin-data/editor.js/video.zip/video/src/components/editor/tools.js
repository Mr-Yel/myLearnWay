import { HttpService } from "../../services/httpService.js";
import Header from '@editorjs/header';
import ImageTool from '@editorjs/image';
import RawTool from '@editorjs/raw';
import Quote from '@editorjs/quote';
import List from '@editorjs/list';
import Checklist from '@editorjs/checklist';
import ScreenShot from './plugins/screenShot.js'
import ScreenShotImg from './plugins/screenShotImg.js'
import ScreenShotFlag from './plugins/ScreenShotFlag.js'
import { url } from "../../config/index.js";
import Stars from "./plugins/stars.js";
//editor工具
export const editorTool = {
    header: {
        class: Header,
        config: {
            placeholder: 'Enter a header',
            levels: [2, 3, 4, 5, 6],
            defaultLevel: 6
        }
    },
    image: {
        class: ImageTool,
        config: {
            uploader: {
                /**
                 * Upload file to the server and return an uploaded image data
                 * @param {File} file - file selected from the device or pasted by drag-n-drop
                 * @return {Promise.<{success, file: {url}}>}
                 */
                uploadByFile(file) {
                    console.log("uploadByFile...");
                    let formData = new FormData();
                    formData.append("file", file);
                    return HttpService.upload(
                        url.baseUrl + "/api/v1/upload",
                        formData
                    ).then((res) => {
                        return {
                            success: res.success,
                            file: {
                                url: res.data.imgUrl,
                                // any other image data you want to store, such as width, height, color, extension, etc
                            },
                        };
                    });
                },

                /**
                 * Send URL-string to the server. Backend should load image by this URL and return an uploaded image data
                 * @param {string} url - pasted image URL
                 * @return {Promise.<{success, file: {url}}>}
                 */
                uploadByUrl(fileUrl) {
                    console.log("uploadByUrl...");
                    return HttpService.post(url.baseUrl + "/api/v1/upload/url", {
                        url: fileUrl,
                    }).then((res) => {
                        return {
                            success: res.success,
                            file: {
                                url: res.data.imgUrl,
                                // any other image data you want to store, such as width, height, color, extension, etc
                            },
                        };
                    });
                },
            },
        },
    },
    raw: {
        class: RawTool,
        config: {
            //   placeholder: 'Enter HTML',
        }
    },
    quote: {
        class: Quote,
        inlineToolbar: true,
        shortcut: 'CMD+SHIFT+O',
        config: {
            quotePlaceholder: 'Enter a quote',
            captionPlaceholder: 'Quote\'s author',
        },
    },
    list: {
        class: List,
        inlineToolbar: true,
    },
    checklist: {
        class: Checklist,
        inlineToolbar: true,
    },
    // screenShot: ScreenShot,
    // screenShotImg:ScreenShotImg,
    // screenShotFlag:ScreenShotFlag
    stars:Stars
}