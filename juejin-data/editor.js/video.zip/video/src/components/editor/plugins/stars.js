// import { NoEmitOnErrorsPlugin } from "webpack";

import { getScreenShotTime, getScreenShot } from "../../video/video.js";

import { emitter } from "../../../utils/mitt.js";

import { timeChange } from "../../../utils/timeChange.js";

import { playerInstance } from "../../video/video.js";

export default class Stars {
    constructor({ data, api }) {
        this.newClickScreenShot = null;
        this.api = api;
        this.data = {
            value: data.value || '',
        };
        this.wrapper = undefined;
        this.settings = [{
            name: "starsError",
            icon: `<svg t="1643362604789" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2993" width="15" height="15"><path d="M512 1024C229.232 1024 0 794.768 0 512 0 229.232 229.232 0 512 0 794.768 0 1024 229.232 1024 512 1024 794.768 794.768 1024 512 1024ZM560 240C560 213.488 538.512 192 512 192 485.488 192 464 213.488 464 240L464 592C464 618.512 485.488 640 512 640 538.512 640 560 618.512 560 592L560 240ZM512 736C485.488 736 464 757.488 464 784 464 810.512 485.488 832 512 832 538.512 832 560 810.512 560 784 560 757.488 538.512 736 512 736Z" p-id="2994"></path></svg>`,
        },

        // {
        //     name: "stretched",
        //     icon: `<svg width="17" height="10" viewBox="0 0 17 10" xmlns="http://www.w3.org/2000/svg"><path d="M13.568 5.925H4.056l1.703 1.703a1.125 1.125 0 0 1-1.59 1.591L.962 6.014A1.069 1.069 0 0 1 .588 4.26L4.38.469a1.069 1.069 0 0 1 1.512 1.511L4.084 3.787h9.606l-1.85-1.85a1.069 1.069 0 1 1 1.512-1.51l3.792 3.791a1.069 1.069 0 0 1-.475 1.788L13.514 9.16a1.125 1.125 0 0 1-1.59-1.591l1.644-1.644z"/></svg>`,
        // },

        // {
        //     name: "withBackground",
        //     icon: `<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10.043 8.265l3.183-3.183h-2.924L4.75 10.636v2.923l4.15-4.15v2.351l-2.158 2.159H8.9v2.137H4.7c-1.215 0-2.2-.936-2.2-2.09v-8.93c0-1.154.985-2.09 2.2-2.09h10.663l.033-.033.034.034c1.178.04 2.12.96 2.12 2.089v3.23H15.3V5.359l-2.906 2.906h-2.35zM7.951 5.082H4.75v3.201l3.201-3.2zm5.099 7.078v3.04h4.15v-3.04h-4.15zm-1.1-2.137h6.35c.635 0 1.15.489 1.15 1.092v5.13c0 .603-.515 1.092-1.15 1.092h-6.35c-.635 0-1.15-.489-1.15-1.092v-5.13c0-.603.515-1.092 1.15-1.092z"/></svg>`,
        // },
        ];
    }

    static get toolbox() {
        return {
            title: "Stars",
            icon: `<svg t="1643354325673" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2065" width="15" height="15"><path d="M957.258525 404.23316c-3.78431-11.352931-13.589115-19.609609-25.458088-21.501764l-270.406182-41.799429L540.640349 82.394759c-5.332437-11.180917-16.513355-18.40551-28.898371-18.40551 0 0 0 0 0 0-12.385016 0-23.565933 7.052579-28.898371 18.40551l-121.78599 258.021166L90.135394 381.183269c-11.868974 1.720141-21.673778 9.976818-25.630102 21.32975s-1.032085 23.909961 7.396607 32.510667L268.342012 637.140265 221.38216 921.995632c-2.064169 12.040988 3.096254 24.25399 13.073072 31.306568 9.976818 7.052579 23.221905 7.740635 33.88678 1.892155L510.193852 822.227448l241.335797 133.826978c4.816395 2.580212 10.148833 3.956325 15.48127 3.956325 0.172014 0 0.516042 0 0.688056 0 17.717453 0 31.994625-14.277171 31.994625-31.994625 0-3.956325-0.688056-7.740635-2.064169-11.352931l-44.895683-278.662859 196.956157-201.256509C958.118596 428.143121 961.042836 415.586091 957.258525 404.23316z" p-id="2066"></path></svg>`,
        };
    }

    renderSettings() {
        const wrapper = document.createElement("div");

        this.settings.forEach((tune) => {
            let button = document.createElement("div");
            button.classList.add(this.api.styles.settingsButton);
            button.classList.toggle(
                this.api.styles.settingsButtonActive,
                this.data[tune.name]
            );
            button.innerHTML = tune.icon;
            wrapper.appendChild(button);
            button.addEventListener("click", () => {
                this._toggleTune(tune.name);
                button.classList.toggle(this.api.styles.settingsButtonActive);
            });
        });

        return wrapper;
    }

    clickScreenShot() {
        this.wrapper.getElementsByClassName("cdx-button")[0].style.display = "none";
        let imagePreloader = this.wrapper.getElementsByClassName("cdx-loader")[0]
        imagePreloader.style.display = "block"
        getScreenShot((result) => {
            this.data.file = { url: result.data.imgUrl };
            let img = this.wrapper.getElementsByClassName("screenShot-image")[0]
            img.src = result.data.imgUrl;
            img.style.display = "block"
            let timeText;
            let timeBox = this.wrapper.getElementsByClassName("screenShot-time")[0]
            if (this.data.time) {
                timeText = document.createTextNode(timeChange(this.data.time));
            } else {
                timeText = document.createTextNode(timeChange(getScreenShotTime()));
                this.data.time = getScreenShotTime();
            }
            timeBox.appendChild(timeText);
            timeBox.addEventListener("click", () => {
                emitter.emit("timeJump", this.data.time);
            });
            imagePreloader.style.display = "none"
        });
    }
    /*
     * 组件初始化数据加载判断
     */
    _newDataSelect() {
        let imageBox = this.wrapper.getElementsByClassName("screenShot-imgbox")[0]
        let image = imageBox.childNodes[0]
        let timeBox = this.wrapper.getElementsByClassName("screenShot-time")[0]
        if (this.data.file.url) {
            if (!imageBox.children) {
                return console.log("图片初始化失败");
            }
            image.src = this.data.file.url;
            let timeText;
            if (this.data.time) {
                timeText = document.createTextNode(timeChange(this.data.time));
            } else {
                timeText = document.createTextNode(timeChange(getScreenShotTime()));
                this.data.time = getScreenShotTime();
            }
            timeBox.appendChild(timeText);
            timeBox.addEventListener("click", () => {
                emitter.emit("timeJump", this.data.time);
            });
        } else {
            image.style.display = "none"
            let button = this.make("div", [this.api.styles.button]);
            button.innerHTML = "Click to tack screenShot";
            imageBox.appendChild(button);
            this.newClickScreenShot = this.clickScreenShot.bind(this);
            button.addEventListener("click", this.newClickScreenShot);
        }
    }

    render() {
        this.wrapper = document.createElement("DIV");
        this.wrapper.className = "lock-divider";
        let inputBox = document.createElement("div");
        inputBox.className = "inputBox";
        let inputflag = document.createElement("div");
        inputflag.innerHTML = `<svg t="1643354325673" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2065" width="15" height="15"><path d="M957.258525 404.23316c-3.78431-11.352931-13.589115-19.609609-25.458088-21.501764l-270.406182-41.799429L540.640349 82.394759c-5.332437-11.180917-16.513355-18.40551-28.898371-18.40551 0 0 0 0 0 0-12.385016 0-23.565933 7.052579-28.898371 18.40551l-121.78599 258.021166L90.135394 381.183269c-11.868974 1.720141-21.673778 9.976818-25.630102 21.32975s-1.032085 23.909961 7.396607 32.510667L268.342012 637.140265 221.38216 921.995632c-2.064169 12.040988 3.096254 24.25399 13.073072 31.306568 9.976818 7.052579 23.221905 7.740635 33.88678 1.892155L510.193852 822.227448l241.335797 133.826978c4.816395 2.580212 10.148833 3.956325 15.48127 3.956325 0.172014 0 0.516042 0 0.688056 0 17.717453 0 31.994625-14.277171 31.994625-31.994625 0-3.956325-0.688056-7.740635-2.064169-11.352931l-44.895683-278.662859 196.956157-201.256509C958.118596 428.143121 961.042836 415.586091 957.258525 404.23316z" p-id="2066"></path></svg>`
        let inputerror = document.createElement("div");
        inputerror.innerHTML = `<svg t="1643362604789" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2993" width="15" height="15"><path d="M512 1024C229.232 1024 0 794.768 0 512 0 229.232 229.232 0 512 0 794.768 0 1024 229.232 1024 512 1024 794.768 794.768 1024 512 1024ZM560 240C560 213.488 538.512 192 512 192 485.488 192 464 213.488 464 240L464 592C464 618.512 485.488 640 512 640 538.512 640 560 618.512 560 592L560 240ZM512 736C485.488 736 464 757.488 464 784 464 810.512 485.488 832 512 832 538.512 832 560 810.512 560 784 560 757.488 538.512 736 512 736Z" p-id="2994"></path></svg>`
        let input = document.createElement("input");
        input.value = this.data.value
        input.onchange = () => {
            this.data.value = input.value
        }
        inputBox.appendChild(inputflag)
        inputBox.appendChild(inputerror)
        inputBox.appendChild(input)
        this.wrapper.appendChild(inputBox)
        return this.wrapper;
    }

    /**
     * @private
     * Click on the Settings Button
     * @param {string} tune — tune name from this.settings
     */
    _toggleTune(tune) {
        this.data[tune] = !this.data[tune];
        this._acceptTuneView();
    }

    /**
     * Add specified class corresponds with activated tunes
     * @private
     */
    _acceptTuneView() {
        this.settings.forEach((tune) => {
            this.wrapper.classList.toggle(tune.name, !!this.data[tune.name]);
        });
    }

    make(tagName, classNames = null, attributes = {}) {
        const el = document.createElement(tagName);
        if (Array.isArray(classNames)) {
            el.classList.add(...classNames);
        } else if (classNames) {
            el.classList.add(classNames);
        }
        for (const attrName in attributes) {
            el[attrName] = attributes[attrName];
        }
        return el;
    }

    save() {
        return Object.assign(this.data, {

        });
    }
validate(savedData) {
    console.log(savedData);
    if (!savedData.value.trim()){
        return false;
    }
    return true;
}
}