import { storage } from "../../utils/storage.js"
import { ExeQrCode } from "../../utils/exe-qr-code.js";
import { HttpService } from "../../services/httpService.js";
import { loginQrCodeParams } from "./config.js";
import swal from "sweetalert";

window.addEventListener('token:invalid', () => {
    logout();
})

// 登录方法
async function initExeqrCode({ getQrCodeUrl, qrCodeStateUrl }) {
    return new Promise((resolve,reject)=>{
        new ExeQrCode({
            container: "qrContainer",
            className: "",
            getQrCodeUrl,
            qrCodeStateUrl,
            timeout: 5000,
            scanText: " ",
            onLoginSuccess: (data) => {
                if (data && data.ticket) {
                    resolve(data)
                }else{
                    reject()
                }
            },
        });
    })
}

// 判断登录
function checkLogin() {
    if (storage.getData("userData") && storage.getData("token")) {
        return true
    }
    return false
}

// 显示主页
function showHome($data) {
    const user = document.querySelector('#user')
    const login = document.querySelector('.login')
    login.style.display = 'none'
    user.src = $data ? $data : "https://res.exexm.com/src/assets/images/common/headPortrait.png"
}

// 显示登录
async function showLogin() {
    const login = document.querySelector('.login')
    login.style.display = 'block'
    const data = await initExeqrCode(loginQrCodeParams)
    if (data && data.ticket) {
        storage.setData("userData", data)
        await getToken()
        showHome(data.picture)
    }
}

// 获取token
async function getToken() {
    const ticket = await storage.getData('userData').ticket
    const data = await HttpService.exeTicketLogin(ticket)
    storage.setData('token', data.data.token)
}

// 检测token
export async function checkToken() {
    if (storage.getData('token')) {
        const result = await HttpService.validToken()
        if (result && result.success && result.data.token) {
            console.log("没失效");
            return
        }
        console.log("token已失效，请重新登录!");
        console.log(result.data.token);
        logout()
    }
    // showLogin()
}

export const logout = () => {
    swal({
        icon:'info',
        title:'登陆以失效'
    })
    storage.delData('token')
    storage.delData('userData')
    window.location.href="./";
}

export const clickLogout = () => {
    storage.delData('token')
    storage.delData('userData')
    window.location.href="./";
}

export const login = () => {
    return new Promise(async(resolve, reject) => {
        if (!checkLogin()) {
            showLogin()
            const data = await initExeqrCode(loginQrCodeParams)
            if (data && data.ticket) {
                storage.setData("userData", data)
                await getToken()
                showHome(data.picture)
                resolve()
            }
        } else {
            await checkToken()
            showHome(storage.getData('userData').picture)
            resolve()
        }
    })
}