//登录接口
export const loginQrCodeParams = {
    // getQrCodeUrl: "https://t-sso.exexm.com/qrlogin.ashx", // 获取APPid接口
    // qrCodeStateUrl: "https://t-sso.exexm.com/qrlogin.ashx", // 轮询接口
    getQrCodeUrl: 'https://sso.exexm.com/qrlogin.ashx', // 正式获取APPid接口
    qrCodeStateUrl: 'https://sso.exexm.com/qrlogin.ashx', // 正式轮询接口
}