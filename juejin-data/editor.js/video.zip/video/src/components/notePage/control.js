import { HttpService } from "../../services/httpService.js";
import { storage } from "../../utils/storage.js"
import { url } from "../../config/index.js";
import { renderNoteList, renderPageNum } from "./initNotePage.js";
import {debounce} from "../../utils/debounce.js"

//监听文章点击
export async function listenNote() {
    const noteList = document.querySelectorAll('.note-list-item ')
    noteList.forEach((item, index) => {
        item.addEventListener('click',
        // debounce({
        //     method: () => {
        //         editor.blocks.insert(exeTool[item].className)
        //     },
        //     delay: 500,
        // })
         async function(e) {
            for (let i = 0; i < noteList.length; i++) {
                noteList[i].className = 'note-list-item'
            }
            item.className = item.className + " checked"  
            if (e.target && e.target.dataset) {
                const { type, index } = e.target.dataset
                if (type == 'delete') {
                    // if (confirm('是否删除文章？')) {
                    delNote(index).then(async(res) => {
                            // location.reload()
                            await renderNoteList()
                            initNotePage()
                            renderPageNum()
                        })
                        // }
                    return
                } 
            }
            upDataEdit(index)
        })
    })
}

//刷新edit内容
async function upDataEdit(index) {
    const iframe = document.querySelector('#iframe-container')
    iframe.contentWindow.postMessage({
        type: 'noteIndex',
        index: index
    }, '*');
}

//禁止编辑
function banEdit() {
    document.querySelectorAll('[contenteditable=true]').forEach(item => { item.setAttribute("contenteditable", "false") })
}

//删除笔记
async function delNote(index) {
    const result = await HttpService.delete(url.baseUrl + '/api/v1/blocks/' + storage.getData('noteIdList')[index])
    return result
}

//计算页数
export async function computePage() {
    const { noteNum } = await getNoteList()
    const page = Math.ceil(noteNum / 10)
    return page
}

//获取文章列表   
export async function getNoteList(num) {
    const noteData = await HttpService.get(url.baseUrl + '/api/v1/blocks', num ? num : 1)
    const noteList = await noteData.data.list
    const noteNum = await noteData.data.count
    return { noteList, noteNum }
}

//监听保存编辑事件
function listenSavaNote() {
    const tools = document.querySelector('.tools')
    tools.addEventListener("click", async function(e) {
        if (e.target && e.target.dataset) {
            const { type } = e.target.dataset
            if (type == 'edit') {
                e.target.className = 'save'
                e.target.dataset.type = 'save'
                editNote('edit')
                return
            }
            if (type == 'save') {
                e.target.className = 'edit'
                e.target.dataset.type = 'edit'
                editNote('save')
                saveEdit()
                return
            }

        }
    })
}

//编辑笔记
async function editNote(data) {
    const iframe = document.querySelector('#iframe-container')
    iframe.contentWindow.postMessage({
        type: 'editNote',
        value: data
    }, '*');
}

//保存data
async function saveEdit() {
    const index = noteNum()
    const iframe = document.querySelector('#iframe-container')
    iframe.contentWindow.postMessage({
        type: 'save',
        index: index
    }, '*');
}

// 获取当前noteNum
function noteNum() {
    const num = Object.keys(storage.getData('noteIdList')).indexOf(storage.getData('noteId'))
    return num
}

//当前全部笔记信息
async function initNoteDate(num) {
    const noteData = await HttpService.get(url.baseUrl + '/api/v1/blocks', num ? num : 1)
    storage.setData('noteDataList', noteData.data.list)
}

//获取全部笔记id
async function getNoteId(data) {
    const { noteList } = await getNoteList(data)
    let noteIdList = {}
    noteList.forEach((item, index) => {
        noteIdList[index] = item._id
    });
    storage.setData('noteIdList', noteIdList)
}

//默认显示第一篇文章
async function initNotePage() {
    const noteList = document.querySelectorAll('.note-list-item ')
    const mainContent = document.querySelector('.main-content ')
    const mainContentNone = document.querySelector('.main-content-none ')
    const page = document.querySelector('.main-page ')
    if (!noteList.length) {
        mainContent.style.display = 'none'
        page.style.display = 'none'
        mainContentNone.style.display = 'flex'
        return
    }
    noteList[0].className = "note-list-item  checked"
    await upDataEdit(0)
    banEdit()
}

export async function control() {
    await initNotePage()
    initNoteDate()
    getNoteId()
    listenSavaNote()
}