import { getNoteList, computePage, listenNote } from "./control.js";

//创建header
async function initHeader() {
    const { noteNum } = await getNoteList()
    const header = document.createElement('section')
    header.className = "note-header"
    const content = `<div class="header-title">
        <span class="header-text">笔记列表</span>
        <span class="header-count">视频笔记 共${noteNum}篇</span>
    </div>`
    header.innerHTML = content
    return header

}

//创建main
function initMain() {
    const main = document.createElement('section')
    main.className = 'note-main'
    const content = `
    <div class="main-title">
        <span class="main-title-tab main-title-mine">
            我的笔记
        </span>
        <span class="main-title-tab main-title-publish" style = 'display: none'>
            公开笔记
        </span>
    </div>
    <div class="main-content">
    </div>
    <div class="main-content-none">
        <img src="//s1.hdslb.com/bfs/static/jinkela/note-list/assets/no_data.png" alt="">
        <p>没有笔记快去添加</p>
    </div>
    <div class="main-page">
    </div>
    `
    main.innerHTML = content
    return main
}

//创建content
async function initMainContent() {
    const mainContent = document.querySelector('.main-content')
    const ul = await createNoteList()
    const edit = await createNoteEdit()
    mainContent.append(ul)
    mainContent.append(edit)
    await renderNoteList()
}

//渲染列表
export async function renderNoteList(index) {
    const ul = document.querySelector('.note-list')
    let noteListTemplate = ''
    const { noteList } = await getNoteList(index)
    noteList.forEach((item, index) => {
        item.updateDate =
            noteListTemplate = noteListTemplate + `
        <li class="note-list-item">
            <div class="note-list-item-cover cover">
                <img src=${item.cover} alt="">
            </div>
            <div class="note-list-item-info">
                <div class="info-title">
                    <div class="note-item__detail--title">
                        <span>${item.title}</span>
                    </div>
                    <div title=" ..." class="note-item__detail--summary">
                    ...
                    </div>
                </div>
                <div class="info-bottom">
                    <span class="update-mtime">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/PjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+PHN2ZyB0PSIxNjE1NTQ1MzY2NTU0IiBjbGFzcz0iaWNvbiIgdmlld0JveD0iMCAwIDEwMjQgMTAyNCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHAtaWQ9IjU2NjciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iNjQiIGhlaWdodD0iNjQiPjxkZWZzPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+PC9zdHlsZT48L2RlZnM+PHBhdGggZD0iTTUxMiAxMjhhMzg0IDM4NCAwIDEgMCAwIDc2OEEzODQgMzg0IDAgMCAwIDUxMiAxMjh6IG0wIDY4Mi42ODhhMjk4LjY4OCAyOTguNjg4IDAgMSAxIDAtNTk3LjM3NiAyOTguNjg4IDI5OC42ODggMCAwIDEgMCA1OTcuMzc2eiIgcC1pZD0iNTY2OCIgZmlsbD0iI2JhYzhkMiI+PC9wYXRoPjxwYXRoIGQ9Ik01NTQuNjg4IDI5OC42ODhINDY5LjMxMnYyNTZINjQwVjQ2OS4zMTJINTU0LjY4OHoiIHAtaWQ9IjU2NjkiIGZpbGw9IiNiYWM4ZDIiPjwvcGF0aD48L3N2Zz4=" alt="" class="update-mtime__icon">
                        <span>更新于 ${setTime(item.updateDate)}</span>
                    </span>
                </div>
            </div>
            <div class="note-list-item-control">
                <a target="_blank" href="//www.bilibili.com/video/BV1WY411a7Xa?note=open" class="go-video-btn">
                    前往视频
                    </a>
                <div class="control-delete" >
                    <img data-type = 'delete' data-index = ${index}
                    src="//s1.hdslb.com/bfs/static/jinkela/note-list/assets/icon_lajitong.svg" alt="" class="note-item__delete--icon">
                </div>
            </div>
        </li>
        `
    });
    ul.innerHTML = noteListTemplate
    listenNote()
}

//分割时间
function setTime(data) {
    const arr = data.split('T')
    const arr2 = arr[1].split(":")
    const newStr = arr[0] + '  ' + arr2[0] + ":" + arr2[1]
    return newStr
}

//创建列表
async function createNoteList() {
    const ul = document.createElement('ul')
    ul.classList = 'note-list'
    return ul
}

//创建edit
async function createNoteEdit() {
    const edit = document.createElement('div')
    edit.classList = 'note-edit'
    const content = `<div class="note-edit-title">
    <h5 class="text" title="加载完成">加载完成</h5>
    <div class="tools">
        <span class=" edit" data-type = "edit"></span>
        <span class=" edit-publish-btn">公开发布</span>
    </div>
</div>
<div class="note-editor">
    <iframe src="./iframe.html" frameborder="0" id="iframe-container"></iframe>
</div>`
    edit.innerHTML = content
    return edit
}

//创建PageNum
async function initPageNum() {
    const page = document.querySelector('.main-page')
    page.innerHTML = `<button type="button" disabled="disabled" class="btn-prev">
            <i class="icon-arrow-left iconfont" data-type = "prev"></i>
            </button>
            <ul class="pager">
                
            </ul>
            <button type="button" disabled="disabled" class="btn-next">
                <i class="icon-arrow-right iconfont"  data-type = "next"></i>
            </button>`
    await renderPageNum()

    let nowPage = 1
    const pageTypeMap = {
        async next() {
            const pageNum = document.querySelectorAll('.number')
            const nextBtnL = document.querySelector('.icon-arrow-left')
            const nextBtnR = document.querySelector('.icon-arrow-right')
            if (nowPage < pageNum.length) {
                nowPage++
                initPage(nowPage)
                const data = { page: parseInt(nowPage), pageSize: 10 }
                renderNoteList(data)
                nextBtnL.style.cursor = 'pointer'
                nextBtnR.style.cursor = 'pointer'
                if (nowPage == pageNum.length) {
                    nextBtnR.style.cursor = 'no-drop'
                }
            }
        },
        async prev() {
            const nextBtnL = document.querySelector('.icon-arrow-left')
            const nextBtnR = document.querySelector('.icon-arrow-right')
            if (nowPage > 1) {
                nowPage--
                initPage(nowPage)
                const data = { page: parseInt(nowPage), pageSize: 10 }
                renderNoteList(data)
                nextBtnL.style.cursor = 'pointer'
                nextBtnR.style.cursor = 'pointer'
                if (nowPage == 1) {
                    nextBtnL.style.cursor = 'no-drop'
                }
            }
        },
        async pageNum(index) {
            if (nowPage == index) return
            initPage(index)
            const data = { page: parseInt(index), pageSize: 10 }
            renderNoteList(data)
            nowPage = index
            const pageNum = document.querySelectorAll('.number')
            const nextBtnL = document.querySelector('.icon-arrow-left')
            const nextBtnR = document.querySelector('.icon-arrow-right')
            if (index == pageNum.length) {
                nextBtnR.style.cursor = 'no-drop'
                nextBtnL.style.cursor = 'pointer'
            }
            if (index == 1) {
                nextBtnL.style.cursor = 'no-drop'
                nextBtnR.style.cursor = 'pointer'
            }
        }
    }
    page.addEventListener('click', (e) => {
        if (e.target && e.target.dataset) {
            const { type, index } = e.target.dataset
            if (pageTypeMap[type]) {
                pageTypeMap[type]()
            }
            if (index) {
                pageTypeMap.pageNum(index)
            }
        }
    })
}

//渲染页码
export async function renderPageNum() {
    const pageUl = document.querySelector('.pager')
    const pageNum = await computePage()
    let pageList = ''
    for (let i = 0; i < pageNum; i++) {
        pageList = pageList + `<li class="number" data-index = "${i+1}">${i+1}</li>`
    }
    pageUl.innerHTML = pageList
}

//初始化换页
function initPage(index = 1) {
    const pageNum = document.querySelectorAll('.number')
    for (let i = 0; i < pageNum.length; i++) {
        pageNum[i].className = 'number'
    }
    if (!pageNum.length) {
        return
    }
    pageNum[index - 1].className = pageNum[index - 1].className + " active"
    const nextBtnL = document.querySelector('.icon-arrow-left')
    const nextBtnR = document.querySelector('.icon-arrow-right')
    nextBtnL.style.cursor = 'no-drop'
    if (pageNum.length == 1) {
        nextBtnR.style.cursor = 'no-drop'
    }
}

//合并页面 
async function createPage() {
    const page = document.createElement('div')
    page.className = 'note-page'
    const body = document.querySelector('body')
    body.append(page)
    const header = await initHeader()
    page.append(header)
    const main = initMain()
    page.append(main)
    await initMainContent()
    await initPageNum()
    initPage()
}

export async function init() {
    await createPage()

}