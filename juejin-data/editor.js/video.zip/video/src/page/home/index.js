import { login, clickLogout } from "../../components/login/login.js";
import { video } from "../../components/video/video.js";
import { editorPage, editor } from "../../components/editor/editor.js";
import { dragSplit } from "../../utils/dragSplit.js";
// import { dragFunctions } from "./components/dragNote/drag.js";
import { iframeConnect } from "../../components/postMate/videoPostMate.js"
import { storage } from "../../utils/storage.js";
import { drag } from "../../components/dragNote/index.js";
import '../../assets/style/index.css'


async function main() {
    try {
        await login()
        renderHerder()
        await video({
            loop: true,
            poster: "",
            url: "https://sf1-cdn-tos.huoshanstatic.com/obj/media-fe/xgplayer_doc_video/mp4/xgplayer-demo-720p.mp4"
        })
        editorPage()
        dragSplit(".video", ".note", ".mid")
        drag()
        iframeConnect()

        // window.onload = window.onresize = dragFunctions()
        exelogout()
        openNote()
    } catch {

    }
}
main()

// 打开笔记弹窗
function openNote() {
    // editor.readOnly.toggle();
    const open = document.querySelector('.write-note')
    const drag = document.querySelector('#drag')
    open.addEventListener('click', function() {
        if (drag.style.display == 'block') return
        drag.style.display = 'flex'
        const iframe = document.querySelector('#iframe-container')
        iframe.contentWindow.postMessage({
            type: 'token',
            value: storage.getData('token')
        }, '*');
    })
    open = null
}
function exelogout(){
    const exeLogout = document.querySelector(".exeLogout")
    exeLogout.addEventListener("click",()=>{
        clickLogout()
    })
}
function renderHerder(){
    let header = document.querySelector(".header")
    let main = document.querySelector(".main")
    header.style = ''
    main.style = ''
}