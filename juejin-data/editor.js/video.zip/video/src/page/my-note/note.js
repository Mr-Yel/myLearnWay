import { init } from '../../components/notePage/initNotePage.js'
import { control } from '../../components/notePage/control.js'
import '../../assets/style/note.css'
import { iframeConnect } from "../../components/postMate/videoPostMate.js"
import { checkToken } from "../../components/login/login.js"

async function main() {
    await checkToken()
    await init()

    iframeConnect('hello')
    control()
}
main()